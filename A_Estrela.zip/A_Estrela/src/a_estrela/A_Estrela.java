package a_estrela;

public class A_Estrela {

    public static void main(String[] args) {
       
    }
    
}
