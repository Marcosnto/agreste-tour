/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a_estrela;

/**
 *
 * @author Layla
 */
class Heuristica {
    
    private float valorHeuristica;
    private Vertice nomedestino;

    public Heuristica(float valorHeuristica, Vertice nomedestino) {
        this.valorHeuristica = valorHeuristica;
        this.nomedestino = nomedestino;
    }
    
    public float getValorHeuristica() {
        return valorHeuristica;
    }

    public void setValorHeuristica(float valorHeuristica) {
        this.valorHeuristica = valorHeuristica;
    }

    public Vertice getNomedestino() {
        return nomedestino;
    }

    public void setNomedestino(Vertice nomedestino) {
        this.nomedestino = nomedestino;
    }
    
}
