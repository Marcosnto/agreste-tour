/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aestrela;

import java.util.Scanner;

/**
 *
 * @author Layla
 */
public class Teste {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        GerarGrafo G = new GerarGrafo();
        BuscaAestrela busca = new BuscaAestrela();
        String verticeInicial;
        String verticedestino;

        G.gerar_Grafo();
        //G.impressao();

        System.out.println("==========================Resultado do Algoritimo A*=================================");
        System.out.println("Informe a cidade Inicial:");
        verticeInicial = entrada.next();
        System.out.println("Informe a cidade destino:");
        verticedestino = entrada.next();
        System.out.println("O melhor caminho de "+verticeInicial+" Para: "+verticedestino+" é: ");

        Vertice cidadeInicial = new Vertice();
        Vertice cidadeDestino = new Vertice();

        for (Vertice vertice : G.grafo) {
            if (vertice.getNomeCidade().equalsIgnoreCase( verticeInicial )) {
                cidadeInicial = vertice;
            }
            if (vertice.getNomeCidade().equalsIgnoreCase(verticedestino)) {
                cidadeDestino = vertice;
            }
        }

        Vertice verticeFinal = busca.aestrela(G.grafo, cidadeInicial, cidadeDestino);
        String percurso = "";
        while (verticeFinal != null) {
            percurso = verticeFinal.getNomeCidade() + (percurso.isEmpty() ? "" : " => " + percurso);
            verticeFinal = verticeFinal.getVerticePai();
        }
        System.out.println(percurso);
    }
}
